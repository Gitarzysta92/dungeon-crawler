import { BoardHelper } from "../../lib/features/board/board-helper";
import { CoordsHelper } from "../../lib/features/board/coords-helper";
import { StateGenerator } from "../../lib/state/state-generator";
import { borgoPlayerDeploymentOrder, gameConfiguration, getTurnsIterator, hegemonyPlayerDeploymentOrder, IScenarioDeclaration } from '../data-set';
import { ArmyHelperMock } from "./mocks/army-helper.mock";
import { GameHelperMock } from "./mocks/game-helper.mock";
import { IGameState } from "../../lib/state/interfaces/game-state.interface";
import { ActivityName } from "../../lib/activities/constants/activity-name";
import { directivesMap } from "../../lib/activities/directives-map";
import { GameDispatcher } from "../../lib/state/game-dispatcher";
import { getPossibileActivities } from "../../lib/activities/guidence-map";
import { TileType } from "../../lib/features/army/constants/tile-type.enum";
import { UnitTile } from "../../lib/features/army/models/unit-tile";
import { borgo } from "../../lib/data/armies/borgo/borgo";
import { GameSegment } from "../../lib/state/constants/game-state-name";
import { ActionTile } from "../../lib/features/army/models/action-tile";


describe('HexChess - hot seat', () => {
  const boardHelper = new BoardHelper(CoordsHelper);
  const stateGenerator = new StateGenerator(ArmyHelperMock, CoordsHelper, GameHelperMock, boardHelper);
  const gameDispatcher = new GameDispatcher(boardHelper);

  let initialState;

  beforeEach(() => {
    initialState = stateGenerator.createInitialState(gameConfiguration);
    // console.log(JSON.stringify(borgo));
    // console.log(JSON.stringify(hegemony));
  });

  it('should go through whole game and pick a winner', () => {
    let state: IGameState = initialState;

    const borgoTurn = getTurnsIterator(borgoPlayerDeploymentOrder);
    const hegemonyTurn = getTurnsIterator(hegemonyPlayerDeploymentOrder);

    while (state.winnerId == null) {
      const turnDeclarations = (state.actualPlayer.data?.armyId === borgo.id ? borgoTurn : hegemonyTurn)
        .next().value! as IScenarioDeclaration[];

      shouldStartTurn(gameDispatcher, state);
      shouldDrawTiles(gameDispatcher, state);

      const tilesToDiscard = turnDeclarations
        .filter(td => td.toDiscard)
        .map(td => td.tileDefinitionId);
      if (!!tilesToDiscard) {
        shouldDiscardTiles(gameDispatcher, state, tilesToDiscard);
      }
      
      for (let tile of state.actualPlayer.playablesSlot) {
        const d = turnDeclarations.find(td => td.tileDefinitionId === tile.tileDefinitionId)!;
        if (d.tileDefinitionId !== tile.tileDefinitionId || d.toDiscard) {
          continue;
        }
        shouldUseTile(gameDispatcher, state, d);
      }

      if (state.gameSegment !== GameSegment.Battle) {
        shouldFinishTurn(gameDispatcher, state);
      }
    }

    expect(state.winnerId).toBeTruthy();
    expect(state.gameSegment).toEqual(GameSegment.Ended);
    expect(state.activityStack[0].name).toEqual(ActivityName.FinishTurn);
  });
});


function shouldStartTurn(gameDispatcher: GameDispatcher, state: IGameState): void {
  const authority = {} as any;
  const activities = getPossibileActivities(state, authority);
  //# start test part
  expect(activities.length).toEqual(1);
  expect(activities[0]).toEqual(ActivityName.StartTurn);
  //# end test part
  state = gameDispatcher.next(directivesMap[ActivityName.StartTurn](), state, authority);
  //# start test part
  expect(state.activityStack.length).toEqual(2);
  expect(state.activityStack[0].name).toEqual(ActivityName.StartTurn);
  expect(state.actualPlayer).toBeTruthy();
  expect(state.actualPlayer.playablesSlot.length).toEqual(0);
  //# end test part
}

function shouldDrawTiles(gameDispatcher: GameDispatcher, state: IGameState): void {
  const authority = {} as any;
  const activities = getPossibileActivities(state, authority);
  //# start test part
  expect(activities.length).toEqual(1);
  expect(activities[0]).toEqual(ActivityName.DrawTiles);
  //# end test part
  state = gameDispatcher.next(directivesMap[ActivityName.DrawTiles](), state, authority);
  //# start test part
  expect(state.activityStack.length).toEqual(3);
  expect(state.activityStack[0].name).toEqual(ActivityName.DrawTiles);
  expect(state.actualPlayer.playablesSlot.length).toEqual(1);
  {
    const tile = ArmyHelperMock.getTile(state.actualPlayer.data?.armyId!, state.actualPlayer.playablesSlot[0].tileDefinitionId);
    expect(tile.type).toEqual(TileType.Headquarter);
  }
  //# end test part
}

function shouldDiscardTiles(gameDispatcher: GameDispatcher, state: IGameState, tileIds: string[]) {
  const authority = {} as any;
  const activities = getPossibileActivities(state, authority);
  //# start test part
  expect(activities.length).toEqual(1);
  expect(activities[0]).toEqual(ActivityName.DiscardTiles);
  //# end test part
  {
    state = gameDispatcher.next(
      directivesMap[ActivityName.DiscardTiles]({
        tileBindings: state.actualPlayer.playablesSlot
          .filter(t => tileIds.includes(t.tileDefinitionId))
      }),
      state, authority);
  }
  //# start test part
  expect(state.activityStack.length).toEqual(4);
  expect(state.activityStack[0].name).toEqual(ActivityName.DiscardTiles);
  expect(state.actualPlayer.playablesSlot.length).toEqual(2);
  //# end test part
}

function shouldUseTile(gameDispatcher: GameDispatcher, state: IGameState, scenarioDeclaration: IScenarioDeclaration): void {
  const authority = {} as any;
  const activities = getPossibileActivities(state, authority);
  //# start test part
  expect(activities.length).toEqual(4);
  expect(activities.some(a => a === ActivityName.DeployTile)).toBeTruthy();
  //# end test part
  {
    const tile = state.actualPlayer.playablesSlot
      .map(t => ArmyHelperMock.getTile(state.actualPlayer.data?.armyId!, t.tileDefinitionId))
      .find(t => t.id === scenarioDeclaration.tileDefinitionId);
    
    if (tile?.type === TileType.Action) {
      const activityName = activities.find(a => a === ActivityName.DisposeActionTile) as ActivityName.DisposeActionTile
      state = gameDispatcher.next(
        directivesMap[activityName]({ tile: tile as ActionTile, coords: scenarioDeclaration.coords! }),
        state, authority);
    } else {
      const activityName = activities.find(a => a === ActivityName.DeployTile) as ActivityName.DeployTile
      state = gameDispatcher.next(
        directivesMap[activityName]({ tile: tile as UnitTile, coords: scenarioDeclaration.coords! }),
        state, authority);
    }
  }
  //# start test part
  expect(state.activityStack.length).toEqual(4);
  expect(state.activityStack[0].name).toEqual(ActivityName.DiscardTiles);
  expect(state.actualPlayer.playablesSlot.length).toEqual(2);
  //# end test part  
}


function shouldFinishTurn(gameDispatcher: GameDispatcher, state: IGameState) {
  const authority = {} as any;
  const activities = getPossibileActivities(state, authority);
  //# start test part
  expect(activities.length).toEqual(1);
  expect(activities[0]).toEqual(ActivityName.FinishTurn);
  //# end test part
  {
    state = gameDispatcher.next(directivesMap[ActivityName.FinishTurn](),state, authority);
  }
  //# start test part
  expect(state.activityStack.length).toEqual(4);
  expect(state.activityStack[0].name).toEqual(ActivityName.FinishTurn);
  expect(state.actualPlayer.playablesSlot.length).toEqual(0);
  //# end test part
}