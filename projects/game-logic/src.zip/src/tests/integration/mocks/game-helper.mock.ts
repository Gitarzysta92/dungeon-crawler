import { gameConfiguration } from "../../data-set";

export class GameHelperMock {

  static generatePlayersOrder(playerIds: string[]): string[] {
    return gameConfiguration.players.map(p => p.id);
  }

}