import { ArmyHelper } from "../../../lib/features/army/army-helper";
import { BoardHelper } from "../../../lib/features/board/board-helper";
import { CoordsHelper } from "../../../lib/features/board/coords-helper";
import { GameHelper } from "../../../lib/features/game/game-helper";
import { GameStateName } from "../../../lib/state/constants/game-state-name";
import { StateGenerator } from "../../../lib/state/state-generator";
import { createGameConfiguration } from "../../tests-helper";


describe('Initial state generator', () => {
  let stateGenerator: StateGenerator;
  const boardHelper: BoardHelper = new BoardHelper(CoordsHelper);

  beforeEach(() => {
    stateGenerator = new StateGenerator(ArmyHelper, CoordsHelper, GameHelper, boardHelper);
  });

  it('expect true to be true', () => {
    const cfg = createGameConfiguration();
    const state = stateGenerator.createInitialState(cfg);

    expect(state).toBeTruthy();
    expect(Object.keys(state.players).length).toEqual(cfg.playersNumber);
    expect(state.name).toEqual(GameStateName.Started);
  });
        
});

