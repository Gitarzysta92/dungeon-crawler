import { borgo } from "../lib/data/armies/borgo/borgo";
import { hegemony } from "../lib/data/armies/hegemony/hegemony";
import { BoardHelper } from "../lib/features/board/board";
import { ICoords } from "../lib/features/board/interfaces/coords";
import { GameMode } from "../lib/game/interfaces/game-configuration";

export const borgoPlayer = {
  id: "a2e29b33-6356-43ed-82e8-3ff452a56b5c",
  nickname: "BorgoPlayer",
  armyId: borgo.id,
  teamId: 1
};

export interface IScenarioDeclaration {
  name: string;
  rotationShift?: number;
  coords?: ICoords;
  toDiscard: boolean;
  tileDefinitionId: string;
}

export function* getTurnsIterator(scenario: IScenarioDeclaration[][]): Generator<IScenarioDeclaration[]> {
  while (scenario.length > 0) {
    yield scenario.shift() || [];
  }
}

export const borgoPlayerDeploymentOrder = [
  //1 turn
  //Headquarter
  [{
    name: "headquarter",
    rotationShift: 0,
    coords: { r: 0, s: -2, q: +2 },
    toDiscard: false,
    tileDefinitionId: '80030423-5a49-435c-8649-f3570c2f6e9a'
  }],
  // 2 turn
  [{
    name: "battle",
    toDiscard: false,
    tileDefinitionId: 'e6a25993-e0f3-4d62-ab0a-849b5de6fb4c'
  },
  {
    name: "claws",
    rotationShift: 0,
    coords: { r: 1, s: -2, q: 1 },
    toDiscard: false,
    tileDefinitionId: '971632f1-fab7-428d-87e0-8f585342507e'
  }],
  // 3 turn
  [{
    name: "officer",
    toDiscard: true,
    tileDefinitionId: 'be4756ef-5da3-489a-85b1-cad9832c9d26'
  },
  {
    name: "claws",
    rotationShift: 5,
    coords: { r: -1, s: 0, q: 1 },
    toDiscard: false,
    tileDefinitionId: '971632f1-fab7-428d-87e0-8f585342507e'
  },
  {
    name: "scout",
    rotationShift: 0,
    coords: { r: -1, s: -1, q: 2 },
    toDiscard: false,
    tileDefinitionId: '8a81e036-b3fc-4f3e-bd98-97b6b31bf4a9'
  }],
  // 4 turn
  [{
    name: "mutant",
    toDiscard: true,
    tileDefinitionId: 'f51665bc-344e-4a12-a0c3-8eaaf876d1c2'
  },
  {
    name: "battle",
    toDiscard: false,
    tileDefinitionId: 'e6a25993-e0f3-4d62-ab0a-849b5de6fb4c'
  },
  {
    name: "super mutant",
    rotationShift: 0,
    coords: { r: 0, s: -1, q: 1 },
    toDiscard: true,
    tileDefinitionId: '971632f1-fab7-428d-87e0-8f585342507e'
  }],

  // //Battle
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'e6a25993-e0f3-4d62-ab0a-849b5de6fb4c'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'e6a25993-e0f3-4d62-ab0a-849b5de6fb4c'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'e6a25993-e0f3-4d62-ab0a-849b5de6fb4c'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'e6a25993-e0f3-4d62-ab0a-849b5de6fb4c'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'e6a25993-e0f3-4d62-ab0a-849b5de6fb4c'
  // },
  // //Move
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '6b11b757-0bb8-4666-9cc9-ea5d5c063612'
  // },
  // //Granade
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '64e53835-e658-4bf6-8bbf-fa31c546e9cc'
  // },
  // //medic
  // {
  //   name: "medic",
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: false,
  //   tileDefinitionId: '29d7cbea-84a6-43f1-b4d3-325e50a0bbe0'
  // },
  // //officer 2
  // {
  //   name: "officer",
  //   rotationShift: 0,
  //   coords: { r: -1, s: -1, q: 2 },
  //   toDiscard: false,
  //   tileDefinitionId: '8a81e036-b3fc-4f3e-bd98-97b6b31bf4a9'
  // },
  // //Super officer
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '618b87ec-4516-4fb8-ab79-6bd8fd6a0e94'
  // },
  // //Scout
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '8a81e036-b3fc-4f3e-bd98-97b6b31bf4a9'
  // },
  // //Assasin
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '27f1b80e-e2ba-4131-9031-765fa4f5ad81'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '27f1b80e-e2ba-4131-9031-765fa4f5ad81'
  // },
  // //Brawler
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '2828aa42-fcaf-4fd1-be13-f551d5abb5c8'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '2828aa42-fcaf-4fd1-be13-f551d5abb5c8'
  // },
  // //Net fighter
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '9648234e-bd0b-4f75-88ce-7488c0f241e4'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '9648234e-bd0b-4f75-88ce-7488c0f241e4'
  // },
  // //Claws
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '971632f1-fab7-428d-87e0-8f585342507e'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: '971632f1-fab7-428d-87e0-8f585342507e'
  // },
  // //Mutant
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'f51665bc-344e-4a12-a0c3-8eaaf876d1c2'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'f51665bc-344e-4a12-a0c3-8eaaf876d1c2'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'f51665bc-344e-4a12-a0c3-8eaaf876d1c2'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'f51665bc-344e-4a12-a0c3-8eaaf876d1c2'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   toDiscard: true,
  //   tileDefinitionId: 'f51665bc-344e-4a12-a0c3-8eaaf876d1c2'
  // },
];

export const hegemonyPlayer = {
  id: "1a8a4d74-d4df-4979-9a89-c97062749a58",
  nickname: "HegemonyPlayer",
  armyId: hegemony.id,
  teamId: 2
};

export const hegemonyPlayerDeploymentOrder = [
  // 1 turn
  //Headquarter
  [{
    name: "headquarter",
    toDiscard: false,
    rotationShift: 0,
    coords: { r: 0, s: 0, q: 0 },
    tileDefinitionId: 'e467d0c7-b0f7-466c-aa76-d856ab87dd2c'
  }],
  // 2 turn
  [{
    name: "runner",
    toDiscard: false,
    rotationShift: 1,
    coords: { r: 0, s: -1, q: +1 },
    tileDefinitionId: '1d0f7d68-8650-4c5d-b2e4-98ee2c40d230'
  }],
  // 3 turn
  [{
    name: "push",
    toDiscard: true,
    tileDefinitionId: '52329582-835a-4e27-bf38-cdf88fc90e5e'
  },
  {
    name: "universal soldier",
    toDiscard: false,
    rotationShift: 1,
    coords: { r: 0, s: 1, q: 1 },
    tileDefinitionId: '503e9d2b-0ae8-44a1-9bbe-971b33fb93fb'
  },
  {
    name: "officer 2",
    toDiscard: false,
    rotationShift: 0,
    coords: { r: 1, s: 0, q: -1 },
    tileDefinitionId: '3224c8c3-8dd5-4123-92cc-b2064f673298'
  }],
  // 4 turn
  [{
    name: "ganger",
    toDiscard: true,
    tileDefinitionId: '1c727430-85bf-4078-89ef-838db4c5d84c'
  },
  {
    name: "net fighter",
    toDiscard: false,
    rotationShift: 1,
    coords: { r: +1, s: -1, q: 0 },
    tileDefinitionId: 'd69d0a79-9a27-474e-89f0-23bbfbb2700f'
  },
  {
    name: "universal soldier",
    toDiscard: false,
    rotationShift: 0,
    coords: { r: -2, s: 2, q: 0 },
    tileDefinitionId: '503e9d2b-0ae8-44a1-9bbe-971b33fb93fb'
  }],

  // //Runner
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1d0f7d68-8650-4c5d-b2e4-98ee2c40d230'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1d0f7d68-8650-4c5d-b2e4-98ee2c40d230'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1d0f7d68-8650-4c5d-b2e4-98ee2c40d230'
  // },
  // //Thug
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '44e5a3ec-735a-4196-a86f-0b63a60b1414'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '44e5a3ec-735a-4196-a86f-0b63a60b1414'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '44e5a3ec-735a-4196-a86f-0b63a60b1414'
  // },
  // //Ganger
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1c727430-85bf-4078-89ef-838db4c5d84c'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1c727430-85bf-4078-89ef-838db4c5d84c'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1c727430-85bf-4078-89ef-838db4c5d84c'
  // },
  // //Gladiator
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '3c3cd958-98dd-4798-9a8c-d5ffce1c9b1f'
  // },
  // //Net fighter

  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'd69d0a79-9a27-474e-89f0-23bbfbb2700f'
  // },
  // //Net master
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1f8165fc-3c93-44cd-81a1-05d1f634b760'
  // },
  // //Guard
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '1ce351ed-fc6e-486d-ac5f-c2b8797786e0'
  // },
  // //Universal soldier
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '503e9d2b-0ae8-44a1-9bbe-971b33fb93fb'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '503e9d2b-0ae8-44a1-9bbe-971b33fb93fb'
  // },
  // //The Boss
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '2e552e29-31fc-4c11-9e65-a2056a70b511'
  // },
  // //Officer
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'be4756ef-5da3-489a-85b1-cad9832c9d26'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'be4756ef-5da3-489a-85b1-cad9832c9d26'
  // },
 
  // //Scout
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'b51fc615-faa6-4c8c-9046-c627a53b0148'
  // },
  // //Transport
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'b36398ad-d219-4456-b2c4-3c1160ec9bcc'
  // },
  // //Sniper
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'f7d202ae-3257-4f5c-8bd9-e7f40b291be1'
  // },
  // //Move
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '8410f971-82be-47c0-b016-49123b928be2'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '8410f971-82be-47c0-b016-49123b928be2'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '8410f971-82be-47c0-b016-49123b928be2'
  // },
  // //Battle
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'dfc22002-6121-4e76-b20a-0239740014ac'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'dfc22002-6121-4e76-b20a-0239740014ac'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'dfc22002-6121-4e76-b20a-0239740014ac'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'dfc22002-6121-4e76-b20a-0239740014ac'
  // },
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: 'dfc22002-6121-4e76-b20a-0239740014ac'
  // },
  // //Push back
  
  // {
  //   rotationShift: 0,
  //   coords: { r: 0, s: 0, q: 0 },
  //   tileDefinitionId: '52329582-835a-4e27-bf38-cdf88fc90e5e'
  // },
];

export const gameConfiguration = {
  mode: GameMode.Skirmish,
  playersNumber: 2,
  players: [borgoPlayer, hegemonyPlayer],
  boardSize: 5,
  drawPerTurn: 3,
  startingLife: 35,
  teams: [{ id: 1, playersNumber: 1 }, { id: 1, playersNumber: 1 }],
  tilesToKeepPerTurn: 3
};

