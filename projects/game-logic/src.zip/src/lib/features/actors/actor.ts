import { BoardCoordinates, BoardObject } from "../board/board.interface";
import { IEffect } from "../effects/effects.interface";
import { IUsable } from "../../game/interactions.interface";

export enum ActorType {
  Hero,
  Character,
  Enemy,
  DungeonDeck,
  Obstacle,
  Board,
  BoardEffect,
  Treasure
}


export interface IActor {
  actorType: ActorType;
  effects: any[];
  groupId: string;
}

export interface IBasicStats {
  health: number;
  attackPower: number;
  spellPower: number;
}


export enum EnemyType {
  Beast
}

export interface Enemy extends IActor, BoardObject, IBasicStats {
  level: number;
  enemyType: EnemyType;
}

export interface Obstacle extends IActor, BoardObject { }

export interface DungeonDeck extends IActor {
  cardsToUtilize: string[],
  utilizedCards: string[]
}

export interface BoardEffect extends IEffect {
  position: BoardCoordinates;
}

export interface Treasure extends IActor, BoardObject, IUsable {

}

export interface Character {
  id: string;
  name: string;
  assignedAreaId: string;
}