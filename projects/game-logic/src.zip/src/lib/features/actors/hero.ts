import { ActorType, IActor, IBasicStats } from "./actor";



export interface IHeroStats extends IBasicStats {
  defence: number;
  source: number;
  speed: number;
  sight: number;
}

export interface HeroStats extends IBasicStats {
  defence: number;
  source: number;
  speed: number;
  sight: number;
}

export interface IHero extends IActor, HeroStats {
  level: number;
  majorActions: number;
  minorActions: number;
  moveActions: number;
  stats: HeroStats;
}


export class Hero implements IHero {
  level!: number;
  majorActions!: number;
  minorActions!: number;
  moveActions!: number;
  stats!: IHeroStats;
  effects!: any[];
  groupId!: string;
  id!: string;
  maxStack!: number;
  characterId!: string;
  maxItems!: number;

  defence!: number;
  source!: number;
  speed!: number;
  sight!: number;
  health!: number;
  attackPower!: number;
  spellPower!: number;
  actorType!: ActorType;

  constructor(data: IHero) {

  }


}