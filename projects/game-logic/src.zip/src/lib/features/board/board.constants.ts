export enum TileSide {
  Top,
  TopRight,
  BottomRight,
  Bottom,
  BottomLeft,
  TopLeft
}