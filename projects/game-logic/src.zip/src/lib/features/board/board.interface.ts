export interface Field {
  id: string;
  coords: BoardCoordinates;
  assignedObject: BoardObject[];
}

export type BoardCoordinates = { r: number, q: number, s: number };
export type BoardRotation = 0 | 1 | 2 | 3 | 4 | 5;
export interface BoardObject {
  id: string;
  rotation: BoardRotation;
  position: BoardCoordinates;
}

export interface IBoardObjectSelector {
  selectorType: 'line' | 'cone' | 'radius' | 'global';
  selectorTargets: 'single' | 'multiple' | 'all';
  origin: BoardCoordinates;
  selectorRange: number;
  selectorBitmap?: any;
  selectionThreshold?: number;
}