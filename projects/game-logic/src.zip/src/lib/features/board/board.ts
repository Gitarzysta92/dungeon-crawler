import { IDictionary } from "../../extensions/types";
import { IActor, IBasicStats } from "../actors/actor";
import { BoardCoordinates, BoardObject, IBoardObjectSelector, Field } from "./board.interface";

export class Board {

  coords: BoardCoordinates[];
  fields: IDictionary<Field>;

  constructor(data: Board) {
    this.coords = data.coords;
    this.fields = data.fields;
  }

  public removeObject(a: IActor & IBasicStats & BoardObject) {
    
  }

  public getSelectedObjects(selector: IBoardObjectSelector, coords?: BoardCoordinates[]): BoardObject[] {


    switch (selector.selectorType) {
      case "line":
        break;
      
      case "cone":
        break;
      
      case "radius":
        break;
      
    
      default:
        break;
    }


    if (selector.selectorType = "cone") {

    } 

    if (selector.origin) {

    }

    return [];
  }

  public getSelectedFields(action: IBoardObjectSelector): BoardObject[] {
    return [];
  }


  // public initialize(size: number): IBoard {
  //   const coords = this._coordsHelper.createHexagonalBoardCoords(size);
  //   return {
  //     coords: coords,
  //     fields: Object.fromEntries(coords.map(c => [this._getFieldKey(c), {} as Field]))
  //   }
  // }

  // public assingdTile(tile: Tile, coord: ICoords, board: IBoard): IBoard {
  //   if (this.isFieldOccupied(coord, board)) {
  //     throw new Error(`Cannot assing to field: ${JSON.stringify(coord)}. Field is already occupied.`)
  //   }
  //   board.fields[this._getFieldKey(coord)].tile = tile;
  //   return board;
  // }

  // public removeTile(coord: ICoords, board: IBoard): IBoard {
  //   if (board.fields[this._getFieldKey(coord)]?.tile) {
  //     board.fields[this._getFieldKey(coord)].tile = null;
  //   }
  //   return board;
  // }

  // public getFields(coords: ICoords[], board: IBoard): Field[] {
  //   return coords.map(c => board.fields[this._getFieldKey(c)])
  //     .filter(f => !!f);
  // }

  // public isFieldOccupied(coord: ICoords, board: IBoard): boolean {
  //   return !!board.fields[this._getFieldKey(coord)]?.tile
  // }


  // private _getFieldKey(coord: ICoords): string {
  //   return `${coord.q}${coord.r}${coord.s}`
  
}