export interface IEffect {
  
}