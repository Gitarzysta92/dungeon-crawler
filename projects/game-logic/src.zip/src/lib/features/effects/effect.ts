export class Effect {
  
}