import { ActorType } from "../actors/actor";
import { HeroStats } from "../actors/hero";
import { IBoardObjectSelector } from "../board/board.interface";
import { ActionType, DamageType } from "./action.constants";


export interface UtilizationCost {
  costType: 'source' | 'majorAction' | 'minorAction',
  costValue: number;
}

export interface IDealDamage extends IBoardObjectSelector {
  actionType: ActionType.DealDamage;
  damageType: DamageType;
  damageValue: number;
}

export interface IModifyStats extends IBoardObjectSelector {
  actionType: ActionType.ModifyStats;
  statName: keyof HeroStats;
  modiferValue: number;
  modifierType: 'add' | 'substract';
}

export interface IModifyPosition extends IBoardObjectSelector {
  actionType: ActionType.MoveActor;
  preserveRotation: boolean;
}

export interface ISpawnActor {
  actionType: ActionType.SpawnActor;
  enemyId: string;
}

export interface IDeckInteraction {
  type: 'putOnTop' | 'scry' | 'putOnBottom' | 'shuffle' | 'pull' | 'remove' | 'push' | 'reorder',
  amount: number,
}

export interface IAction {
  id: string;
  actionType: ActionType;
  targetingActor: ActorType;
  utilizationCosts?: UtilizationCost[],
}