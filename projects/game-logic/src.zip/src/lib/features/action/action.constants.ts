
export enum ActionType {
  DealDamage,
  SpawnActor,
  ModifyStats,
  MoveActor
}

export enum DamageType {
  Phisical,
  Magical
}