import { IDisposable, IUsable } from "../../game/interactions.interface";
import { IActor, IBasicStats } from "../actors/actor";
import { IHero } from "../actors/hero";
import { Board } from "../board/board";
import { BoardCoordinates, BoardObject, IBoardObjectSelector } from "../board/board.interface";
import { IDealDamage, ISpawnActor, IAction, IModifyStats, IModifyPosition } from "./actions.interface";


export function moveActor(board: Board, action: IModifyPosition & (IDisposable | IUsable), coords?: BoardCoordinates[]) {
  const actors = (board.getSelectedObjects(action as IBoardObjectSelector, coords) as unknown as Array<IActor & IBasicStats & BoardObject>)
    .filter(a => a.actorType === action.targetType && !!(a as unknown as IBasicStats));
  
  
}


export function spawnActor(board: Board, action: ISpawnActor & IBoardObjectSelector, coords?: BoardCoordinates[]) {
  const fields = board.getSelectedFields(action);
  
  if (fields.length <= 0) {
    throw new Error('There are no actors for given board selector')
  }

  fields.forEach(a => {
    a.health -= (action as unknown as IDealDamage).damageValue;
  });
}


export function modifyStatictics(board: Board, action: IModifyStats & (IDisposable | IUsable), coords?: BoardCoordinates[]) {
  const actors = (board.getSelectedObjects(action as IBoardObjectSelector, coords) as unknown as Array<IActor & IBasicStats & BoardObject>)
    .filter(a => a.actorType === action.targetType && !!(a as unknown as IBasicStats));
  
  if (actors.length <= 0) {
    throw new Error('There are no actors for given board selector')
  }

  actors.forEach(a => {
    a.health -= (action as unknown as IDealDamage).damageValue;
  });  
}


export function dealDamage(board: Board, action: IDealDamage & (IDisposable | IUsable), coords?: BoardCoordinates[]) {
  const actors = (board.getSelectedObjects(action as IBoardObjectSelector, coords) as unknown as Array<IActor & IBasicStats & BoardObject>)
    .filter(a => a.actorType === action.targetType && !!(a as unknown as IBasicStats).health);
  
  if (actors.length <= 0) {
    throw new Error('There are no actors for given board selector')
  }

  actors.forEach(a => {
    a.health -= (action as unknown as IDealDamage).damageValue;
  });
}



export function consumeResources(action: IDisposable | IUsable, hero: IHero): IHero | null {
  const heroCopy = Object.assign({}, hero);
  const costPaid = action.utilizationCost.every(auc => {
    if (auc.costType === "source") {
      heroCopy.source -= auc.costValue;
      if (heroCopy.source < 0) {
        return false;
      }
    }
    if (auc.costType === "majorAction") {
      heroCopy.majorActions -= auc.costValue;
      if (heroCopy.source < 0) {
        return false;
      }
    }
    if (auc.costType === "minorAction") {
      heroCopy.majorActions -= auc.costValue;
      if (heroCopy.source < 0) {
        return false;
      }
    }
    return true;
  });

  return costPaid ? heroCopy : null;
}