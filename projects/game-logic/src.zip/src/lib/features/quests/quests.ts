export interface IQuestLog {
  inProgress: IQuestLine[],
  finished: IQuestLine[]
}

export enum QuestOrigin {
  QuestItem,
  Area,
  Character,
  Quest
}

export interface IQuestDialog {
  characterId: string;
  questId: string;
  answears: []
}


export interface IQuestLine {
  id: string;
  quests: IQuest[]
  progress: number;
}

export enum QuestStatus {
  NotStarted,
  Started,
  Finished,
}

export interface IQuest {
  id: string;
  status: QuestStatus,
  prerequisites: string,
  origin: QuestOrigin,
  originId: string,
  objectives: IQuestObjective[],
  reward: Array<IGatherItemObjective | ISlayEnemiesObjective>;
  resolvedVariantId?: string;
  startConsequentQuest?: string;
  questLineId?: string;
  indexInQuestLine?: number;
}

export enum QuestObjectiveType {
  GatherItem,
  SlayEnemies,
}

export interface IQuestObjective {
  objectiveType: QuestObjectiveType;
  reportObjectiveCharacterId: string;
  isDone: boolean;
}

export interface IGatherItemObjective extends IQuestObjective {
  objectiveType: QuestObjectiveType.GatherItem;
  itemId: string;
  amount: number;
}

export interface ISlayEnemiesObjective extends IQuestObjective {
  objectiveType: QuestObjectiveType.GatherItem;
  enemyId: string;
  amount: number;
}

export interface IActiveQuest {
  
}

export class QuestLog {
  activeQuests: IActiveQuest[];
  finishedQuestIds: string[];

  constructor(data: QuestLog) {
    this.activeQuests = data.activeQuests;
    this.finishedQuestIds = data.finishedQuestIds;
  }
}