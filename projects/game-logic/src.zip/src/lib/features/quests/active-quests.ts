export class Quests {
  constructor(quests: Quests) {

  }
}