export interface IAdventureMetadata {

}
