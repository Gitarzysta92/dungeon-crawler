export class AreaMap {
  occupiedAreaId!: string;
  constructor(data: AreaMap) {

  }
}