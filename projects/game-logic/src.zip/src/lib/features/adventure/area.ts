export enum AreaType {
  Dungeon,
  City,
  District,
  Building,

}

export interface IArea {
  id: string;
  name: string;
  parentAreaId?: string;
  accessCondition: boolean;
}

export class Area implements IArea {
  id: string;
  name: string;
  parentAreaId?: string | undefined;
  accessCondition: boolean;
  associatedCharacterIds: string[];

  constructor() {

  }

}