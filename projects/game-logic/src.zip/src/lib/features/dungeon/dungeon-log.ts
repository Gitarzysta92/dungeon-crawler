export class DungeonLog {
  
}