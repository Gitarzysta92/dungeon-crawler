

export interface IDungeonDeck {
  
}


export interface IDungeonCard {
  
}


export class DungeonDeck {
  constructor(data: DungeonDeck) {

  }
}

