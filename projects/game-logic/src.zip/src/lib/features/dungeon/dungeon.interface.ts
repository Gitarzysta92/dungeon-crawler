import { DungeonDeck, Enemy, BoardEffect } from "../actors/actor";
import { IEffect } from "../effects/effects.interface";

export interface IDungeonMetadata {

}


export interface DungeonInstance {
  effects: IEffect[],
  drawPerTurn: number,
  board: any;
  deck: DungeonDeck,
  initialEnemies: Enemy,
  initialBoardEffects: BoardEffect[],
}

export interface IDungeonSummary {

}