export enum ItemType {
  Helmet,
  Armor,
  Boots,
  Sword,
  Bow,
  Staff,
  Wand,
  Shield,
  Potion,
  QuestItem,
  Currency
}

export interface IItem {
  id: string;
  itemType: ItemType;
}

export enum CurrencyType {
  Gold
}

export interface ICurrencyItem extends IItem {
  itemType: ItemType.Currency;
  currencyType: CurrencyType;
}

export interface IPossesedItem {
  id: string;
  amountInStack: number;
  inventoryId: string;
}

export class Currency implements ICurrencyItem {
  id: string;
  itemType: ItemType.Currency;
  currencyType: CurrencyType.Gold;

  constructor() {
    this.id = ''
    this.itemType = ItemType.Currency;
    this.currencyType = CurrencyType.Gold;
  }
}