import { Inventory } from "./inventory";

export class Equipment extends Inventory {

  constructor(data: Equipment) {
    super(data);
  }
}