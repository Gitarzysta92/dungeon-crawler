import { hash } from "../../utils/utils";
import { CurrencyType, ICurrencyItem, IItem, IPossesedItem, ItemType } from "./items";

export interface ItemsContainer {
  slots: number;
}

export interface ItemSlot {
  slotType: ItemSlotType;
}

export enum ItemSlotType {
  Weapon,
  Armor,
  Boots,
  Common,
  Currency
}


export interface IInventory {
  id: string;
  actorId: string;
  maxItems: number;
}


export type InventoryAndItemId = string;


export class Inventory implements IInventory {
  id!: string;
  actorId!: string;
  maxItems!: number;
  items: Array<IPossesedItem & IItem>;

  constructor(data: Inventory) {
    this.items = data.items;
  }

  getItem<T extends IItem>(item: T): T & IPossesedItem | undefined {
    return
  }

  addItem(item: IItem, amount: number): void {

  }

  removeItem(item: IItem, amount: number): void {

  }

  getCurrency(type: CurrencyType): IPossesedItem & ICurrencyItem | undefined {
    return (this.items as Array<IPossesedItem & ICurrencyItem>)
      .find(i => i.itemType === ItemType.Currency && i.currencyType === type);
  }

  increaseCurrencyAmount(amount: number, currencyType: CurrencyType): void {
    let gold = this.getCurrency(currencyType);
    if (!gold) {
      gold = this.createCurrency(amount, currencyType);
      this.items.push(gold)
      return;
    }
    gold.amountInStack += amount; 
  }

  createCurrency(amount: number, currencyType: CurrencyType): IPossesedItem & ICurrencyItem {
    return {
      id: hash(ItemType.Currency.toString() + currencyType.toString()),
      amountInStack: amount,
      currencyType: currencyType,
      inventoryId: this.id,
      itemType: ItemType.Currency
    }
  }

  reduceCurrencyAmount(transactionCost: number, purchaseCurrency: CurrencyType) {
    throw new Error("Method not implemented.");
  }

}