import { UtilizationCost } from "../features/action/actions.interface";
import { ActorType } from "../features/actors/actor";
import { ItemSlotType } from "../features/items/inventory";
import { CurrencyType } from "../features/items/items";


export interface IInteraction {
  interactionType: InteractionType
}


export interface IEquipable extends IInteraction {
  interactionType: InteractionType.Equipable;
  toSlot: ItemSlotType;
  utilizationCost: UtilizationCost[];
  isEquiped?: boolean;
}

export interface IDisposable extends IInteraction {
  interactionType: InteractionType.Disposable;
  targetType: ActorType;
  utilizationCost: UtilizationCost[];
  charges: number;
}

export interface IUsable extends IInteraction {
  interactionType: InteractionType.Usable;
  targetType: ActorType;
  utilizationCost: UtilizationCost[];
}

export interface IPurchasable extends IInteraction {
  interactionType: InteractionType.Purchasable;
  purchaseCurrency: CurrencyType;
  sellBasePrice: number;
  buyBasePrice: number;
}

export enum InteractionType {
  Equipable,
  Disposable,
  Usable,
  Purchasable
}