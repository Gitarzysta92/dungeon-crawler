import { IActivity } from "../activities/interfaces/activity.interface";
import { Hero } from "../features/actors/hero";
import { Board } from "../features/board/board";
import { DungeonDeck } from "../features/dungeon/dungeon-deck";
import { IDungeonMetadata } from "../features/dungeon/dungeon.interface";
import { Effect } from "../features/effects/effect";
import { Equipment } from "../features/items/equipment";
import { Inventory } from "../features/items/inventory";
import { IState } from "../utils/state-dispatcher/interfaces/state.interface";
import { AdventureState } from "./adventure-state";
import { GameLayer } from "./game.constants";

export class DungeonState implements IState {
  gameLayerName: GameLayer.Dungeon;
  turn: number;
  hero: Hero;
  metadata: IDungeonMetadata;
  effects: Effect[];
  board: Board;
  heroEquipment: Equipment;
  heroInventory: Inventory;
  dungeonDeck: DungeonDeck;
  changesHistory: IActivity<{ [key: string]: unknown; }>[];
  prevState: AdventureState | null;

  constructor(
    public data: DungeonState
  ) {
    this.gameLayerName = GameLayer.Dungeon;
    this.turn = 1;
    this.hero = new Hero(data.hero);
    this.metadata = {} as IDungeonMetadata;
    this.effects = [];
    this.board = new Board(data.board)
    this.heroEquipment = new Equipment(data.heroEquipment);
    this.heroInventory = new Inventory(data.heroInventory);
    this.dungeonDeck = new DungeonDeck(data.dungeonDeck);
    this.changesHistory = [];
    this.prevState = null;
  }
}