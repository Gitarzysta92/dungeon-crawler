import { v4 as uuid } from "uuid";
import { ArmyHelper } from "../features/adventure/army-helper";
import { TileDefinitionBinding } from "../features/adventure/interfaces/tile-declaration-binding";
import { BoardHelper } from "../features/board/board";
import { CoordsHelper } from "../features/board/coords.helper";
import { IAction } from "../features/action/interfaces/action";
import { GameHelper } from "./game-helper";
import { IGameConfiguration } from "../game/interfaces/game-configuration";
import { Player } from "../game/interfaces/player";
import { ITileBinding } from "../game/interfaces/tile-bind";
import { IGameState } from "../state-dispatcher/interfaces/game-state.interface";
import { GameSegment } from "./constants/game-state-name";
import { ActivityName } from "../activities/constants/activity-name";
import { IActivity } from "../activities/interfaces/activity.interface";
import { IEffect } from "../features/capabilities/effect/models/effect";


export class StateGenerator {

  constructor(
    private readonly _armyHelper: typeof ArmyHelper,
    private readonly _coordsHelper: typeof CoordsHelper,
    private readonly _gameHelper: typeof GameHelper,
    private readonly _boardHelper: BoardHelper
  ) {}

  createInitialState(cfg: IGameConfiguration): IGameState {
    return {
      id: uuid(),
      round: 0,
      gameSegment: GameSegment.Started,
      metadata: {
        mode: cfg.mode,
        playersNumber: cfg.playersNumber,
        playersOrder: this._gameHelper.generatePlayersOrder(cfg.players.map(p => p.id)),
        boardSize: cfg.boardSize,
        tilesToKeepPerTurn: cfg.tilesToKeepPerTurn
      },
      players: Object.fromEntries(cfg.players.map(p => ([p.id, {
        id: p.id,
        nickname: p.nickname,
        armyId: p.armyId,
        tilesOrder: this._armyHelper.getTilesOrderWithUniqueIdBindings(p.armyId),
        headquarterId: this._armyHelper.getArmyHeadquarter(p.armyId).id
      } as Player]))),
      actualPlayer: {
        data: null,
        playablesSlot: [] as TileDefinitionBinding[],
        actionsSlot: [] as IAction[],
        numberOfTilesToDraw: cfg.drawPerTurn,
        maxPlayablesSlotSize: cfg.tilesToKeepPerTurn
      },
      keepedTiles: [] as ITileBinding[],
      discardedTiles: [] as ITileBinding[],
      utilizedTiles: [] as ITileBinding[],
      activityStack: [
        { name: ActivityName.Initialization }
      ] as IActivity[],
      effects: [] as IEffect[],
      board: this._boardHelper.initialize(cfg.boardSize),
      prevState: null,
      battleResolver: null,
      winnerId: null,
      aggreement: null
    }
  }

}