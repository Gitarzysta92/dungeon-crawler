import { IActivity } from "../activities/interfaces/activity.interface";
import { IDictionary } from "../extensions/types";
import { Hero } from "../features/actors/hero";
import { AreaMap } from "../features/adventure/area-map";
import { DungeonLog } from "../features/dungeon/dungeon-log";
import { Equipment } from "../features/items/equipment";
import { Inventory } from "../features/items/inventory";
import { QuestLog } from "../features/quests/quests";
import { IState } from "../utils/state-dispatcher/interfaces/state.interface";
import { GameLayer } from "./game.constants";


export class AdventureState implements IState {
  gameLayerName: GameLayer.Adventure;
  hero: Hero;
  heroEquipment: Equipment;
  heroInventory: Inventory;
  questLog: QuestLog;
  areaMap: AreaMap;
  dungeonLog: DungeonLog;
  characters: IDictionary<{ inventory: Inventory, assignedAreaId: string }>;
  changesHistory: IActivity<{ [key: string]: unknown; }>[];
  prevState: AdventureState | null;

  constructor(
    public data: AdventureState
  ) {
    this.gameLayerName = GameLayer.Adventure;
    this.hero = new Hero(data.hero);
    this.heroEquipment = new Equipment(data.heroEquipment);
    this.heroInventory = new Inventory(data.heroInventory);
    this.questLog = new QuestLog(data.questLog);
    this.areaMap = new AreaMap(data.areaMap);
    this.dungeonLog = new DungeonLog();
    this.characters = this.data.characters;
    this.changesHistory = [];
    this.prevState = null;
  }
}