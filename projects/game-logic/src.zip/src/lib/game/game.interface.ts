import { IActivity } from "../activities/interfaces/activity.interface";
import { IAction } from "../features/action/actions.interface";
import { Character, Enemy, IHero, Obstacle } from "../features/actors/actor";
import { IArea } from "../features/adventure/area";
import { IDungeonCard, IDungeonDeck } from "../features/dungeon/dungeon-deck";
import { IDungeonSummary, IDungeonMetadata } from "../features/dungeon/dungeon.interface";
import { IEffect } from "../features/effects/effects.interface";
import { IInventory, Inventory, InventoryAndItemId } from "../features/items/inventory";
import { IItem, IPossesedItem } from "../features/items/items";
import { IActiveQuest, IQuest } from "../features/quests/quests";
import { GameLayer, IAdventureMetadata } from "./interfaces/game";


export interface IGameFeed {
  effects: IEffect;
  dungeonCards: IDungeonCard[];
  enemies: Enemy[];
  obstacles: Obstacle[],
  characters: Character[],
  areas: IArea[],
  quests: IQuest[],
  items: IItem[],
  activities: IAction[]
}

export interface IAdventureState {
  gameLayerName: GameLayer.Adventure;
  metadata: IAdventureMetadata;
  hero: IHero;
  heroEquipment: IEquipment;
  heroInventory: IInventory & Inventory;
  activeQuests: IActiveQuest[];
  finishedQuestIds: string[],
  finishedDungeons: IDungeonSummary[],
  occupiedAreaId: string;
  activityStack: IActivity[];
  prevState: IAdventureState | null;
  characterToAreaAssociation: { [key: string]: string },
  characterInventory: { [characterId: string]: IInventory & Inventory }
  inventoryItems: { [key: InventoryAndItemId]: IPossesedItem }
}



export interface IDungeonState {
  gameLayer: GameLayer.Dungeon;
  turn: number; 
  hero: IHero;
  metadata: IDungeonMetadata;
  effects: IEffect[];
  heroActualStatsLevel: IHero;
  board: IBoard;
  dungeonDeck: IDungeonDeck;
  dungeonCards: IDungeonCard[];
  utilizedCards: IDungeonCard[];
  activityStack: IActivity[];
  prevState: IDungeonState | null;
} 