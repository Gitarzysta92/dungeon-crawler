export enum GameLayer {
  Adventure = 'Started',
  Dungeon = 'Ended',
}


export const AdventureLayerAvailableActors = {
  
}