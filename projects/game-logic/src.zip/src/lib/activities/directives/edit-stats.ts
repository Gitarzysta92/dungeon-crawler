import { IBasicStats } from "../../features/actors/actor";
import { IAdventureState } from "../../game/interfaces/game-state.interface";
import { IDispatcherDirective } from "../../utils/state-dispatcher/interfaces/dispatcher-directive.interface";
import { AdventureActivityName } from "../constants/activity-name";


export const editStats = (payload: { stats: IBasicStats }): IDispatcherDirective =>
  function (state: IAdventureState) {

    Object.assign(state.hero, payload.stats);

    return {
      name: AdventureActivityName.EditStats,
      payload: payload
    }
  }