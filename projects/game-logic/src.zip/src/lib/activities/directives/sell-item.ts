
import { IPurchasable } from "../../game/interactions.interface";
import { IItem } from "../../features/items/items";
import { IGameFeed } from "../../game/game.interface";
import { AdventureActivityName } from "../constants/activity-name";
import { AdventureState } from "../../game/adventure-state";
import { IDispatcherDirective } from "../../utils/state-dispatcher/interfaces/dispatcher-directive.interface";
import { Character } from "../../features/actors/actor";


export const sellItem = (payload: { item: IItem & IPurchasable, amount: number, fromCharacter: Character }): IDispatcherDirective =>
  (state: AdventureState, feed: IGameFeed) => {
   
    const areaId = state.characters[payload.fromCharacter.id].assignedAreaId;
    if (state.areaMap.occupiedAreaId !== areaId) {
      throw new Error("Hero is not in the same area as given character");
    }

    const selledItem = state.heroInventory.getItem(payload.item); 
    if (!selledItem || selledItem.amountInStack < payload.amount) {
      throw new Error("Character has not possessing given item");
    }
    
    const transactionCost = payload.item.sellBasePrice * payload.amount;
    const characterInventory = state.characters[payload.fromCharacter.id].inventory;
    state.heroInventory.increaseCurrencyAmount(transactionCost, payload.item.purchaseCurrency);
    state.heroInventory.removeItem(payload.item, payload.amount);
    characterInventory.addItem(payload.item, payload.amount);

    return {
      name: AdventureActivityName.SellItem,
      payload: payload,
    }
  }