import { ActionTile } from "../../features/adventure/models/action-tile";
import { isDrawDisabledEffectValidator } from "../../features/capabilities/effect/effect-validators";
import { Player } from "../../game/interfaces/player";
import { addRandomTilesToPlayablesSlot } from "../../game/mutators/add-random-tiles-to-playable";
import { IDispatcherDirective } from "../../state-dispatcher/interfaces/dispatcher-directive.interface";
import { IGameState } from "../../state-dispatcher/interfaces/game-state.interface";
import { ActivityName } from "../constants/activity-name";

export const disposeAction = (tile: ActionTile): IDispatcherDirective => (state: IGameState, authority?: Player) => {

  if (!isDrawDisabledEffectValidator(state.effects, state.actualPlayer)) {
    addRandomTilesToPlayablesSlot(state.actualPlayer, state.keepedTiles);
  }

  return {
    playerId: state.actualPlayer.data?.id,
    turn: state.round,
    name: ActivityName.DrawTiles,
    rollback: () => ({}) as IGameState
  }
}