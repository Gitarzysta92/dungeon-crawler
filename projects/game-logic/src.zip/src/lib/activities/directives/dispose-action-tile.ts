import { ActionTile } from "../../features/adventure/models/action-tile"
import { ICoords } from "../../features/board/interfaces/coords"
import { ActionType } from "../../features/action/constants/action-type"
import { Player } from "../../game/interfaces/player"
import { GameSegment } from "../../state-dispatcher/constants/game-state-name"
import { IDispatcherDirective } from "../../state-dispatcher/interfaces/dispatcher-directive.interface"
import { IGameContext } from "../../state-dispatcher/interfaces/game-context.interface"
import { IGameState } from "../../state-dispatcher/interfaces/game-state.interface"
import { ActivityName } from "../constants/activity-name"
import { finishTurn } from "./finish-turn"


export const disposeActionTile = (payload: { tile: ActionTile, coords: ICoords }): IDispatcherDirective =>
  function (this: IGameContext, state: IGameState, authority: Player) {

  for (let action of payload.tile.actions) {
    if (ActionType.Battle === action.type) {
      state.gameSegment = GameSegment.Battle;
      disposeBattleActionTile(tile)(state, authority);
      const finishTurnActivity = finishTurn()(state, authority);
      return [
        {
          playerId: state.actualPlayer?.data?.id,
          turn: state.round,
          name: ActivityName.DisposeActionTile,
          rollback: () => ({}) as IGameState
        },
        finishTurnActivity
      ];
    } else {
      switch (action.type) {
    
        case ActionType.Battle:
          return disposeBattleActionTile(tile)(state, authority);      
        
        case ActionType.ModifyAttribute:
          modifyUnitHealth.call(this, state.board, action);
          break;
    
        default:
          break;
      }
    }
  }

  return [
    {
      playerId: state.actualPlayer?.data?.id,
      turn: state.round,
      name: ActivityName.DisposeActionTile,
      rollback: () => ({}) as IGameState
    }
  ];  
  }













  // export const disposeBattleAction = (): IDispatcherDirective =>
  // function (this: IGameContext, state: IGameState, authority?: Player) {

    
  //   const turn = state.activityStack[0].turn;

  //   return [
  //     {
  //       playerId: state.actualPlayer?.data?.id,
  //       turn: turn,
  //       name: ActivityName.DisposeActionTile,
  //       rollback: () => ({}) as IGameState
  //     },
  //     finishTurn().call(this, state, authority!) as IActivity,
  //     {
  //       playerId: state.actualPlayer?.data?.id,
  //       turn: turn,
  //       name: ActivityName.Agreement,
  //       payload: {},
  //       rollback: () => ({}) as IGameState
  //     }
  //   ];
  // }