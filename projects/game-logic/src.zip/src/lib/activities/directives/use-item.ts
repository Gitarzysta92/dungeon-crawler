import { IDisposable, InteractionType, IUsable } from "../../game/interactions.interface";
import { IItem } from "../../features/items/items";
import { IGameFeed } from "../../game/game.interface";
import { AdventureActivityName } from "../constants/activity-name";
import { AdventureState } from "../../game/adventure-state";
import { IDispatcherDirective } from "../../utils/state-dispatcher/interfaces/dispatcher-directive.interface";
import { IAction, IDealDamage, IModifyPosition, IModifyStats, ISpawnActor } from "../../features/action/actions.interface";
import { GameLayer } from "../../game/game.constants";
import { DungeonState } from "../../game/dugneon-state";
import { consumeResources, dealDamage, modifyStatictics, moveActor, spawnActor } from "../../features/action/actions";
import { BoardCoordinates, IBoardObjectSelector } from "../../features/board/board.interface";
import { Character } from "../../features/actors/actor";
import { hero } from "../../data/data";
import { ActionType } from "../../features/action/action.constants";
import { IEffect } from "../../features/effects/effects.interface";

interface UseItemPayload {
  item: IItem & IAction & (IUsable | IDisposable) & IEffect
    & IBoardObjectSelector & (IDealDamage | IModifyStats | IModifyPosition | ISpawnActor),
  target: BoardCoordinates[] | Character[]
}

export const useItem = (payload: UseItemPayload): IDispatcherDirective =>
  (state: AdventureState | DungeonState, feed: IGameFeed) => {
    
    const reducedStats = consumeResources(payload.item, hero);
    if (!reducedStats) {
      throw new Error("");
    }

    const isDungeon = state.gameLayerName === GameLayer.Dungeon;

    if (payload.item.actionType === ActionType.DealDamage && isDungeon) {
      dealDamage(state.board, payload.item, payload.target as BoardCoordinates[]);
    }
  
    if (payload.item.actionType === ActionType.SpawnActor && isDungeon) {
      spawnActor(state.board, payload.item, payload.target as BoardCoordinates[]);
    }
  
    if (payload.item.actionType === ActionType.MoveActor && isDungeon) {
      moveActor(state.board, payload.item, payload.target as BoardCoordinates[]);
    }

    if (payload.item.actionType === ActionType.ModifyStats && isDungeon) {
      modifyStatictics(state.board, payload.item, payload.target as BoardCoordinates[]);
    }
  
    if (isDungeon) {
      state.board.removeObject(a);
    }
    
  
    if (payload.item === ) {

    } 

    if (payload.item.interactionType === InteractionType.Disposable) {
      payload.item.charges -= 1;
    } 

    return {
      name: AdventureActivityName.BuyItem,
      payload: payload,
    }
  }