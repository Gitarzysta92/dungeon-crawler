export const enum AdventureActivityName {
  EditStats,
  BuyItem,
  SellItem,
  UseItem,
  EquipItem,
  StartQuest,
  FinishQuest,
  TravelTo,
  EnterDungeon,
}

export const enum DungeonActivityName {
  UseActivity,
  UseItem,
  EquipItem,
  FinishTurn,
  ExitDungeon,
  EscapeDungeon
}