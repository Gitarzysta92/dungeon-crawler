import { IDispatcherDirective } from "./interfaces/dispatcher-directive.interface";
import { ValidationError } from "../extensions/validation-error";
import { IState } from "./interfaces/state.interface";



export class StateDispatcher {

  constructor(
    private readonly _initializers: Array<(state: IState) => void>,
    private readonly _context: { [key: string]: string },
  ) { }

  public next<T extends IState>(directive: IDispatcherDirective, state: T): T {
    try {
      this._initializers.forEach(i => i(state));
      const activity = directive(state, this._context)
      state.changesHistory.unshift(activity);
      state.prevState = JSON.parse(JSON.stringify(state)) as T;
      return state;
    } catch (error: unknown) {
      if (error instanceof ValidationError) {
        throw error;
        //throw new Error(`Transition between ${current.toString()} and ${activity.name.toString()} failed. Validator name: ${(error as ValidationError).message}:`);
      } else {
        throw error;
      } 
    }
  }

}