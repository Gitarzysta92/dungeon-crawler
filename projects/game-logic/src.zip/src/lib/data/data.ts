// ############################################### User interface

export interface Description {
  name: string;
  description: string;
}

// ############################################## User interactions


// ############################################### Actors


// ######################### Hero
export const hero: Hero = {
  groupId: '',
  level: 1,
  majorActions: 1,
  minorActions: 1,
  moveActions: 1,
  stats: {
    attackPower: 1,
    defence: 1,
    health: 1,
    sight: 1,
    source: 1,
    speed: 1,
    spellPower: 1
  },
  effects: [],
  itemsContainer: undefined
}


// ######################### Enemies
export const rat: Enemy = {
  effects: [],
  groupId: '',
  health: 20,
  attackPower: 10,
  spellPower: 0,
  position: [0, 0, 0],
  rotation: 0,
  level: 0,
  enemyType: EnemyType.Beast
}

export const dungeonDeck: DungeonDeck = {
  effects: [],
  groupId: '',
  cardsToUtilize: [],
  utilizedCards: []
}

export const obstacle: Obstacle = {
  effects: [],
  groupId: '',
  position: [0, 0, 0],
  rotation: 0
}

export const boardEffect: BoardEffect & StatModfier = {
  duration: 0,
  modifierType: "substract",
  modiferValue: 10,
  statName: "health",
  position: [0,0,0]
}

export const treasure: Treasure = {
  effects: [],
  groupId: '',
  interactionResult: '',
  interactionType: InteractionType.Usable,
  rotation: 0,
  position: [0, 0, 0],
}



// ############################################### Effects



// ############################################### Activities

export const fireball: Activity & DamageDealer = {
  activityName: 'Fireball',
  damageType: DamageType.Magical,
  damageValue: 20,
  affectRange: 3,
  affectTargets: 'single',
  affectType: 'line',
  targetingActor: ActorType.Enemy,
  utilizationCosts: [
    {
      costType: 'source',
      costValue: 20
    },
    {
      costType: 'majorAction',
      costValue: 1
    }
  ]
}

export const teleport: Activity & PositionModifier = {
  activityName: 'Teleport',
  affectRange: 3,
  affectTargets: 'single',
  affectType: 'radius',
  targetingActor: ActorType.Hero,
  preserveRotation: false,
  utilizationCosts: [
    {
      costType: 'source',
      costValue: 20
    },
    {
      costType: 'majorAction',
      costValue: 1
    }
  ]
}

export const healing: Activity & StatModfier = {
  activityName: 'Healing',
  modiferValue: 20,
  statName: 'health',
  targetingActor: ActorType.Hero | ActorType.Enemy,
  modifierType: 'add',
  utilizationCosts: [
    {
      costType: 'source',
      costValue: 20
    },
    {
      costType: 'majorAction',
      costValue: 1
    }
  ]
}

export const vision: Activity & DeckInteraction = {
  activityName: 'Vision',
  targetingActor: ActorType.DungeonDeck,
  type: 'scry',
  amount: 2,
  utilizationCosts: [
    {
      costType: 'source',
      costValue: 20
    },
    {
      costType: 'majorAction',
      costValue: 1
    }
  ] 
}



//  ############################################## Items


const staff: Item & Equipable & DamageDealer & StatModfier = {
  name: 'Staff',
  description: '',
  itemType: ItemType.Staff,
  interactionType: InteractionType.Equipable,
  toSlot: ItemSlotType.Weapon,
  damageType: DamageType.Phisical,
  damageValue: 10,
  statName: 'spellPower',
  modiferValue: 1,
  modifierType: 'add',
  affectRange: 1,
  affectTargets: "single",
  affectType: "line",
  utilizationCost: {
    costValue: 1,
    costType: 'majorAction'
  }
}

const potion: Item & Disposable & StatModfier = {
  name: "Potion",
  description: "",
  itemType: ItemType.Potion,
  interactionType: InteractionType.Disposable,
  targetType: ActorType.Hero,
  statName: 'health',
  modiferValue: 20,
  modifierType: 'add',
  utilizationCost: {
    costValue: 20,
    costType: 'source'
  }
}

const questItem: Item = {
  name: "Poo",
  description: "",
  itemType: ItemType.QuestItem,
}


// ############################################# Board


// ############################################# Dungeon Deck


// ############################################### Dungeon layer


// ############################################### Adventure layer


const area: Area = {
  id: 'C183105D-34AB-4101-A54C-0BB26A372094',
  name: '',
  parentAreaId: '',
  accessCondition: false,
}


const character: Character = {
  id: '2038740F-2AA6-4711-9745-154E4AE25976',
  name: '',
  assignedAreaId: '78A02668-7CB3-4555-BA72-139773E554C6',
}


// ############################################### Quest System


export const questLine: QuestLine = {
  id: "6EE7DD33-332D-4D41-8B5C-EAAACA752B36",
  quests: [
    {
      id: "",
      status: QuestStatus.NotStarted,
      prerequisites: "",
      origin: QuestOrigin.QuestItem,
      originId: "",
      objectives: [],
      reward: []
    }
  ]
}
 

export const gatherItemObjective: GatherItemObjective = {
  objectiveType: QuestObjectiveType.GatherItem,
  itemId: "AED17C15-D482-4DFE-B41F-75804BC215A8",
  amount: 0,
  reportObjectiveCharacterId: "2038740F-2AA6-4711-9745-154E4AE25976",
  isDone: false
}

export const slayEnemiesObjective: SlayEnemiesObjective = {
  objectiveType: QuestObjectiveType.GatherItem,
  enemyId: "",
  amount: 0,
  reportObjectiveCharacterId: "",
  isDone: false
}


// ############################################### Activities


export const emptyCard: IDungeonCard & IAction = {
  actionName: 'noop',
  targetingActor: ActorType.Void,
}


export const increaseEnemyAttackPower: IDungeonCard & IAction & StatModfier = {
  actionName: 'increaseEnemyAttackPower',
  targetingActor: ActorType.Enemy,
  modiferValue: 2,
  modifierType: "add",
  statName: "attackPower"
}


export const moveEnemy: IDungeonCard & IAction & PositionModifier = {
  actionName: 'moveEnemy',
  targetingActor: ActorType.Enemy,
  affectRange: 2,
  affectTargets: "single",
  affectType: "line",
  preserveRotation: false,
}


export const spawnEnemy: IDungeonCard & IAction & EnemySpawner = {
  actionName: 'spawnEnemy',
  targetingActor: ActorType.Board,
  enemyId: 'someId'
}


// ###############################################################

export const enum AdventureActivities {
  EditStats,
  BuyItem,
  SellItem,
  UseItem,
  EquipItem,
  StartQuest,
  FinishQuest,
  TravelTo,
  EnterDungeon,
}

export const enum DungeonActivities {
  UseActivity,
  UseItem,
  EquipItem,
  FinishTurn,
  ExitDungeon,
  EscapeDungeon
}








